-- Drive Aura - DB3 Servizio Sanitario
-- Importare in phpMyAdmin dopo avere selezionato un database MySQL/MariaDB.
-- Richiede InnoDB e charset utf8mb4.

CREATE TABLE IF NOT EXISTS cittadino (
    cssn VARCHAR(32) NOT NULL,
    nome VARCHAR(80) NOT NULL,
    cognome VARCHAR(80) NOT NULL,
    data_nascita DATE NOT NULL,
    luogo_nascita VARCHAR(100) NOT NULL,
    indirizzo VARCHAR(200) NOT NULL,
    PRIMARY KEY (cssn),
    KEY ix_cittadino_cognome_nome (cognome, nome, cssn),
    KEY ix_cittadino_nascita (data_nascita),
    KEY ix_cittadino_luogo_nascita (luogo_nascita)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS ospedale (
    codice VARCHAR(20) NOT NULL,
    nome VARCHAR(120) NOT NULL,
    citta VARCHAR(100) NOT NULL,
    indirizzo VARCHAR(200) NOT NULL,
    direttore_sanitario_cssn VARCHAR(32) NOT NULL,
    PRIMARY KEY (codice),
    UNIQUE KEY uq_ospedale_direttore (direttore_sanitario_cssn),
    KEY ix_ospedale_nome (nome, codice),
    KEY ix_ospedale_citta (citta, nome, codice),
    CONSTRAINT fk_ospedale_direttore
        FOREIGN KEY (direttore_sanitario_cssn) REFERENCES cittadino (cssn)
        ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS patologia (
    cod VARCHAR(20) NOT NULL,
    nome VARCHAR(120) NOT NULL,
    criticita TINYINT UNSIGNED NOT NULL,
    PRIMARY KEY (cod),
    KEY ix_patologia_nome (nome, cod),
    KEY ix_patologia_criticita (criticita, cod),
    CONSTRAINT ck_patologia_criticita CHECK (criticita BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS patologia_cronica (
    cod_patologia VARCHAR(20) NOT NULL,
    PRIMARY KEY (cod_patologia),
    CONSTRAINT fk_patologia_cronica
        FOREIGN KEY (cod_patologia) REFERENCES patologia (cod)
        ON UPDATE RESTRICT ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS patologia_mortale (
    cod_patologia VARCHAR(20) NOT NULL,
    PRIMARY KEY (cod_patologia),
    CONSTRAINT fk_patologia_mortale
        FOREIGN KEY (cod_patologia) REFERENCES patologia (cod)
        ON UPDATE RESTRICT ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ricovero (
    cod_ospedale VARCHAR(20) NOT NULL,
    cod INT UNSIGNED NOT NULL,
    paziente_cssn VARCHAR(32) NOT NULL,
    data_inizio DATE NOT NULL,
    durata SMALLINT UNSIGNED NOT NULL,
    motivo VARCHAR(500) NOT NULL,
    costo DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (cod_ospedale, cod),
    KEY ix_ricovero_paziente_data (paziente_cssn, data_inizio, cod_ospedale, cod),
    KEY ix_ricovero_ospedale_data (cod_ospedale, data_inizio, cod),
    KEY ix_ricovero_data (data_inizio, cod_ospedale, cod),
    KEY ix_ricovero_durata (durata),
    KEY ix_ricovero_costo (costo),
    CONSTRAINT fk_ricovero_ospedale
        FOREIGN KEY (cod_ospedale) REFERENCES ospedale (codice)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT fk_ricovero_paziente
        FOREIGN KEY (paziente_cssn) REFERENCES cittadino (cssn)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT ck_ricovero_cod CHECK (cod > 0),
    CONSTRAINT ck_ricovero_durata CHECK (durata BETWEEN 1 AND 3650),
    CONSTRAINT ck_ricovero_costo CHECK (costo >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS patologia_ricovero (
    cod_ospedale VARCHAR(20) NOT NULL,
    cod_ricovero INT UNSIGNED NOT NULL,
    cod_patologia VARCHAR(20) NOT NULL,
    PRIMARY KEY (cod_ospedale, cod_ricovero, cod_patologia),
    KEY ix_pr_patologia_ricovero (cod_patologia, cod_ospedale, cod_ricovero),
    CONSTRAINT fk_pr_ricovero
        FOREIGN KEY (cod_ospedale, cod_ricovero)
        REFERENCES ricovero (cod_ospedale, cod)
        ON UPDATE RESTRICT ON DELETE CASCADE,
    CONSTRAINT fk_pr_patologia
        FOREIGN KEY (cod_patologia) REFERENCES patologia (cod)
        ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contatore per codice progressivo Ricovero, bloccato con SELECT ... FOR UPDATE
-- nella transazione di creazione.
CREATE TABLE IF NOT EXISTS progressivo_ricovero (
    cod_ospedale VARCHAR(20) NOT NULL,
    prossimo_cod INT UNSIGNED NOT NULL,
    PRIMARY KEY (cod_ospedale),
    CONSTRAINT fk_progressivo_ospedale
        FOREIGN KEY (cod_ospedale) REFERENCES ospedale (codice)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT ck_progressivo_ricovero CHECK (prossimo_cod > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
